import setuptools

with open("README.md", "r") as fh:
	long_description = fh.read()

setuptools.setup(
	name="table_understanding",
	version="0.0.1",
	author="1wpro2",
	author_email="jackie.li@oaknorth.com",
	description="A fake table_understanding library",
	long_description=long_description,
	long_description_content_type="text/markdown",
	url="https://github.com/OakNorthAI/ONAIPypi",
	packages=setuptools.find_packages(),
	classifiers=[
		"Programming Language :: Python :: 3",
		"License :: OSI Approved :: MIT License",
		"Operating System :: OS Independent",
	]
)
